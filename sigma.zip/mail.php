<!DOCTYPE html>
<html lang="en">

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Learna - Education HTML Template">

    <!-- ========== Page Title ========== -->
    <title>The Sigma Skool</title>

    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon">

    <!-- ========== Start Stylesheet ========== -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="assets/css/magnific-popup.css" rel="stylesheet">
    <link href="assets/css/swiper-bundle.min.css" rel="stylesheet">
    <link href="assets/css/animate.min.css" rel="stylesheet">
    <link href="assets/css/validnavs.css" rel="stylesheet">
    <link href="assets/css/helper.css" rel="stylesheet">
    <link href="assets/css/unit-test.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <!-- ========== End Stylesheet ========== -->

</head>

<body>

    <!-- Start Preloader 
    ============================================= -->
    <div id="preloader">
        <div id="edufix-preloader" class="edufix-preloader">
            <div class="animation-preloader">
                <div class="spinner"></div>
                <div class="txt-loading">
                    <span data-text-preloader="S" class="letters-loading">
                        S
                    </span>
                    <span data-text-preloader="I" class="letters-loading">
                        I
                    </span>
                    <span data-text-preloader="G" class="letters-loading">
                        G
                    </span>
                    <span data-text-preloader="M" class="letters-loading">
                        M
                    </span>
                    <span data-text-preloader="A" class="letters-loading">
                        A
                    </span>
                    <!-- <span data-text-preloader="X" class="letters-loading">
                        X
                    </span> -->
                </div>
            </div>
            <div class="loader">
                <div class="row">
                    <div class="col-3 loader-section section-left">
                        <div class="bg"></div>
                    </div>
                    <div class="col-3 loader-section section-left">
                        <div class="bg"></div>
                    </div>
                    <div class="col-3 loader-section section-right">
                        <div class="bg"></div>
                    </div>
                    <div class="col-3 loader-section section-right">
                        <div class="bg"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Preloader -->

    <!--[if lte IE 9]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
    <![endif]-->

    <!-- Start Header Top 
    ============================================= -->
    <div class="top-bar-area top-bar-style-one bg-dark text-light">
        <div class="container">
            <div class="row align-center">
                <div class="col-lg-7">
                    <ul class="item-flex">
                        <li>
                            <a href="tel:+4733378901">
                                <img src="assets/img/icon/2.png" alt="Icon"> Phone: +91 9666892000
                            </a>
                        </li>
                        <li>
                            <a href="mailto:name@email.com">
                                <img src="assets/img/icon/3.png" alt="Icon"> Email: support@thesigmaskool.com
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-5 text-end">
                    <div class="item-flex">
                        <!-- <div class="dropdown">
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                <img src="assets/img/icon/flag.png" alt="Image Not Found">
                                English <i class="fas fa-angle-down"></i>
                            </button>
                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                              <li><a class="dropdown-item" href="#">Spanish</a></li>
                              <li><a class="dropdown-item" href="#">Arabic</a></li>
                            </ul>
                        </div> -->
                        <!-- <div>
                            <a href="#"><img src="assets/img/icon/1.png" alt="Icon"> Admin</a>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Header Top -->

    <!-- Header 
    ============================================= -->
    <header>
        <!-- Start Navigation -->
        <nav
            class="navbar mobile-sidenav navbar-sticky navbar-default validnavs dark navbar-fixed no-background inc-topbar">


            <div class="container d-flex justify-content-between align-items-center">

                <!-- Start Header Navigation -->
                <div class="item-flex">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                            <i class="fa fa-bars"></i>
                        </button>
                        <a class="navbar-brand" href="index.html">
                            <img src="assets/img/logo.png" class="logo" alt="Logo">
                        </a>
                    </div>
                    <!-- <form class="search-form" action="#">
                        <input type="text" placeholder="Search" class="form-control" name="text">
                        <button type="submit">
                            <i class="fa fa-search"></i>
                        </button>  
                    </form> -->
                </div>
                <!-- End Header Navigation -->

                <div class="nav-item-box d-flex justify-content-between align-items-center">
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="navbar-menu">

                        <img src="assets/img/logo.png" alt="Logo">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                            <i class="fa fa-times"></i>
                        </button>

                        <ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">
                            <li class="dropdown megamenu-fw megamenu-style-two">
                                <!-- <a href="#" class="dropdown-toggle" data-toggle="dropdown">SIGMA</a>
                                <ul class="dropdown-menu megamenu-content" role="menu">
                                    
                                    <li>
                                        <div class="col-menu-wrap">
                                            <div class="menu-cal-items">
                                                <div class="col-menu">
                                                    <h4>Homepage Layout</h4>
                                                    <ul class="menu-col">
                                                        <li><a href="index.html">Home</a></li>
                                                        <li><a href="index-2.html">Digital Course Hub</a></li>
                                                        <li><a href="index-3.html">Online Academy</a></li>
                                                        <li><a href="index-4.html">Distance learning</a></li>
                                                    </ul>
                                                </div>
                                                <div c4lass="col-menu">
                                                    <h4>Homepage Layout</h4>
                                                    <ul class="menu-col">
                                                        <li><a href="index-5.html">Digital Education</a></li>
                                                        <li><a href="index-6.html">Remote Training</a></li>
                                                        <li><a href="index-7.html">University Classic</a></li>
                                                        <li><a href="index-8.html">Kindergarten</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="megamenu-banner">
                                                <img src="assets/img/thumb/20.jpg" alt="Image Not Found">
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </li> -->
                            <li><a href="index.html">Home</a></li>
                            <li class="dropdown megamenu-fw megamenu-style-four">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Courses</a>
                                <ul class="dropdown-menu megamenu-content" role="menu">
                                    <li>
                                        <div class="col-menu-wrap">
                                            <div class="col-menu">
                                                <h6 class="title">German Language</h6>
                                                <div class="content">
                                                    <ul class="menu-col">
                                                        <li><a href="a1.html">German A1</a></li>
                                                        <li><a href="a2.html">German A2</a></li>
                                                        <li><a href="b1.html">German B1</a></li>
                                                        <li><a href="a1a2.html">German A1+A2</a></li>
                                                        <li><a href="a1a2b1.html">German A1+A2+B1</a></li>
                                                        <li><a href="a2b1.html">German A2+B1</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <!-- <div class="col-menu">
                                                <h6 class="title">Japanese Language</h6>
                                                <div class="content">
                                                    <ul class="menu-col">
                                                        <li><a href="course-filter.html">Comming Soon</a></li>
                                                        <li><a href="course-filter-sidebar.html">Course Filter Sidebar</a></li>
                                                        <li><a href="course-filter-list.html">Course Filter List</a></li>
                                                        <li><a href="course-filter-list-sidebar.html">Course Filter List Sidebar</a></li>
                                                        <li><a href="course-single.html">Course Details</a></li>
                                                        <li><a href="course-single-2.html">Course Details Two</a></li>
                                                    </ul>
                                                </div>
                                            </div> -->
                                        </div><!-- end row -->
                                    </li>
                                </ul>
                            </li>
                            <li><a href="notes.html">Get Notes</a></li>
                            <li class="dropdown megamenu-fw megamenu-style-three">
                                <a href="#aboutus" class="dropdown-toggle" data-toggle="dropdown">Know about Sigma</a>
                                <ul class="dropdown-menu megamenu-content" role="menu">
                                    <li>
                                    <!-- <li><a href="about-us-2.html">About Us Two</a></li> -->
                                    <!-- <li><a href="instructor.html">Instructor</a></li> -->
                                    <li><a href="profile.html">Instructor Profile</a></li>
                                    <li><a href="terms-and-conditions.html">Terms and Conditions</a></li>
                                    <li><a href="privacy-policy.html">privacy-policy</a></li>
                                    <!-- <div class="col-menu-wrap">
                                            <div class="col-menu">
                                                <h6 class="title">Get Started</h6>
                                                <div class="content">
                                                    <ul class="menu-col">
                                                        <li><a href="about-us.html">About Us</a></li>
                                                        <li><a href="about-us-2.html">About Us Two</a></li>
                                                        <li><a href="instructor.html">Instructor</a></li>
                                                        <li><a href="profile.html">Instructor Profile</a></li>
                                                        <li><a href="gallery.html">Gallery</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-menu">
                                                <h6 class="title">Events</h6>
                                                <div class="content">
                                                    <ul class="menu-col">
                                                        <li><a href="event.html">Event Style One</a></li>
                                                        <li><a href="event-2.html">Event Style Two</a></li>
                                                        <li><a href="event-3.html">Event Style Three</a></li>
                                                        <li><a href="event-4.html">Event Style Four</a></li>
                                                        <li><a href="event-single.html">Event Details</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-menu">
                                                <h6 class="title">Important Pages</h6>
                                                <div class="content">
                                                    <ul class="menu-col">
                                                        <li><a href="membership-plan.html">Membership Plan</a></li>
                                                        <li><a href="zoom-meeting.html">Zoom Meeting</a></li>
                                                        <li><a href="zoom-meeting-details.html">Zoom Meeting Details</a></li>
                                                        <li><a href="faq.html">Faqs</a></li>
                                                        <li><a href="privacy-policy.html">Privacy Policy</a></li>
                                                    </ul>
                                                </div>
                                            </div>    
                                            <div class="col-menu">
                                                <h6 class="title">Other Pages</h6>
                                                <div class="content">
                                                    <ul class="menu-col">
                                                        <li><a href="contact-us.html">Contact Us</a></li>
                                                        <li><a href="login.html">Login</a></li>
                                                        <li><a href="register.html">Register</a></li>
                                                        <li><a href="megamenu.html">Megamenu</a></li>
                                                        <li><a href="404.html">Error page</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div> -->
                            </li>
                        </ul>
                        </li>

                        <!-- <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" >Blog</a>
                                <ul class="dropdown-menu">
                                    <li><a href="blog-standard.html">Blog Standard</a></li>
                                    <li><a href="blog-with-sidebar.html">Blog With Sidebar</a></li>
                                    <li><a href="blog-2-colum.html">Blog Grid Two Colum</a></li>
                                    <li><a href="blog-3-colum.html">Blog Grid Three Colum</a></li>
                                    <li><a href="blog-single.html">Blog Single</a></li>
                                    <li><a href="blog-single-with-sidebar.html">Blog Single With Sidebar</a></li>
                                </ul> -->
                        </li>
                        <!-- <li><a href="contact-us.html">Blog</a></li> -->
                        <li><a href="contact-us.html">Contact</a></li>
                        </ul>
                    </div><!-- /.navbar-collapse -->

                    <div class="attr-right">
                        <!-- Start Atribute Navigation -->
                        <div class="attr-nav">
                            <ul>
                                <li class="side-menu">
                                    <a href="#">
                                        <div class="menu-icon">
                                            <span class="bar-1"></span>
                                            <span class="bar-2"></span>
                                            <span class="bar-3"></span>
                                        </div>
                                    </a>
                                </li>
                            </ul>

                        </div>
                        <!-- End Atribute Navigation -->
                    </div>
                </div>

                <!-- Start Side Menu -->
                <div class="side">
                    <a href="#" class="close-side"><i class="fas fa-times"></i></a>
                    <div class="widget">
                        <div class="logo">
                            <img src="assets/img/logo-light.png" alt="Logo">
                        </div>
                        <p>
                            Sigma Skool offers expert-led German language courses guided by high-profile instructors
                            with global teaching experience. Our curriculum emphasizes real-world communication,
                            cultural fluency, and career relevance. Mastering German opens doors to international
                            education, top-tier job markets, and global networking—making language learning an
                            investment in your future success.

                        </p>
                    </div>
                    <div class="widget address">
                        <div>
                            <ul>
                                <li>
                                    <div class="content">
                                        <p>Address</p>
                                        <strong>Hyderabad</strong>
                                    </div>
                                </li>
                                <li>
                                    <div class="content">
                                        <p>Email</p>
                                        <strong>support@thesigmaskool.com</strong>
                                    </div>
                                </li>
                                <li>
                                    <div class="content">
                                        <p>Contact</p>
                                        <strong>+91 9666892000</strong>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="row">
                    <div class="col-xl-8 offset-xl-2 col-lg-10 offset-lg-1">
                        <h2 class="title split-text">Make yourself a Sigma</h2>
                        <ul class="list-check">
                            <li><a class="btn circle btn-theme animation" href="https://wa.me/911234567890">Whatsapp
                                    Us</a></li>
                            <li><a class="btn circle btn-theme animation" href="tel:+919666892000">Call Us</a></li>
                            <li><a class="btn circle btn-theme animation" href="contact-us.html">Contact Us</a></li>
                        </ul>


                    </div>
                </div>
                    <div class="widget social">
                        <ul class="link">
                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                            <!-- <li><a href="#"><i class="fab fa-behance"></i></a></li> -->
                        </ul>
                    </div>

                </div>
                <!-- End Side Menu -->

            </div>
            <!-- Overlay screen for menu -->
            <div class="overlay-screen"></div>
            <!-- End Overlay screen for menu -->
        </nav>
        <!-- End Navigation -->
    </header>
    <!-- End Header -->

                <!-- Start Side Menu -->
                <div class="side">
                    <a href="#" class="close-side"><i class="fas fa-times"></i></a>
                    <div class="widget">
                        <div class="logo">
                            <img src="assets/img/logo-light.png" alt="Logo">
                        </div>
                        <p>
                            Sigma Skool offers expert-led German language courses guided by high-profile instructors with global teaching experience. Our curriculum emphasizes real-world communication, cultural fluency, and career relevance. Mastering German opens doors to international education, top-tier job markets, and global networking—making language learning an investment in your future success.






                        </p>
                    </div>
                    <div class="widget address">
                        <div>
                            <ul>
                                <li>
                                    <div class="content">
                                        <p>Address</p> 
                                        <strong>Hyderabad</strong>
                                    </div>
                                </li>
                                <li>
                                    <div class="content">
                                        <p>Email</p> 
                                        <strong>support@thesigmaskool.com</strong>
                                    </div>
                                </li>
                                <li>
                                    <div class="content">
                                        <p>Contact</p> 
                                        <strong>+91 9666892000</strong>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="widget newsletter">
                        <h4 class="title">Make yourself a SIGMA</h4>
                        <form action="#">
                            <div class="input-group stylish-input-group">
                                <input type="email" placeholder="Enter your e-mail" class="form-control" name="email">
                                <span class="input-group-addon">
                                    <button type="submit" >
                                        <i class="fa fa-long-arrow-right"></i>
                                    </button>  
                                </span>
                            </div>
                        </form>
                    </div>
                    <div class="widget social">
                        <ul class="link">
                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            <li><a href="https://www.linkedin.com/in/shubham-agarwal-313710382/"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="#"><i class="fab fa-behance"></i></a></li>
                        </ul>
                    </div>

                </div>
                <!-- End Side Menu -->

            </div>   
            <!-- Overlay screen for menu -->
            <div class="overlay-screen"></div>
            <!-- End Overlay screen for menu -->
        </nav>
        <!-- End Navigation -->
    </header>
    <!-- End Header -->

     <!-- Start Breadcrumb 
    ============================================= -->
    <div class="breadcrumb-area text-center bg-gray-gradient-secondary">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <h1>Get in Touch</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li><a href="#"><i class="fas fa-home"></i> Home</a></li>
                            <li class="active">Contact</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->

    <!-- Start Contact Us 
    ============================================= -->
    <div class="contact-style-one-area overflow-hidden default-padding-bottom">
        <div class="container">
            <div class="row">

                <div class="contact-stye-one col-lg-10 offset-lg-1">
                    <div class="contact-form-style-one">
                        <h2 class="heading">Send us a message</h2>
                        <form action="contact.php" method="post" class="contact-form contact-form">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <input class="form-control" id="name" name="name" placeholder="Name" type="text" required>
                                        <span class="alert-error"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="email" name="email" placeholder="Email*" type="email" required>
                                        <span class="alert-error"></span>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" id="phone" name="phone" placeholder="Phone" type="text" required>
                                        <span class="alert-error"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group comments">
                                        <textarea class="form-control" id="comments" name="comments" placeholder="Tell Us About Query *" required></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <a href="phpmailer\sucess.html"><button type="submit" name="submit" id="submit">
                                        <i class="fa fa-paper-plane"></i> Get in Touch
                                    </button></a>
                                </div>
                            </div>
                            <!-- Alert Message -->
                            <div class="col-lg-12 alert-notification">
                                <div id="message" class="alert-msg"></div>
                            </div>
                        </form>
                        <img src="assets/img/shape/88.png" alt="Image Not Found">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Contact -->

    <!-- Start Contact Information
    ============================================= -->
    <div class="contact-info-area overflow-hidden default-padding-bottom pt-20 mt--20">
        <div class="container">
            <div class="row">
                <div class="contact-stye-one col-lg-10 offset-lg-1">
                    <div class="contact-style-one-info">
                        <div class="heading text-center">
                            <h4 class="sub-title">Have Questions?</h4>
                            <h2 class="title">Contact Information</h2>
                        </div>
                        <div class="contact-info-items">
                            <div class="item-single wow fadeInUp">
                                <div class="icon">
                                    <img src="assets/img/icon/68.png" alt="Image Not Found">
                                </div>
                                <div class="content">
                                    <h4>Contact Number</h4>
                                    <ul>
                                        <li>
                                            <a href="tel:+4733378901">+91 9666892000</a>
                                        </li>
                                        <!-- <li>
                                            <a href="tel:+1433378912">+1433378912</a>
                                        </li> -->
                                    </ul>
                                </div>
                            </div>
                            <div class="item-single wow fadeInUp" data-wow-delay="300ms">
                                <div class="icon">
                                    <img src="assets/img/icon/70.png" alt="Image Not Found">
                                </div>
                                <div class="info">
                                    <h4>Our Location</h4>
                                    <p>
                                        Ameerpet, 500016, Hyderabad, India
                                    </p>
                                </div>
                            </div>
                            <div class="item-single wow fadeInUp" data-wow-delay="500ms">
                                <div class="icon">
                                    <img src="assets/img/icon/69.png" alt="Image Not Found">
                                </div>
                                <div class="info">
                                    <h4>Official Email</h4>
                                    <ul>
                                        <li>
                                            <a href="mailto:info@edfix.com.com">info@thesigmaskool.com</a>
                                        </li>
                                        <li>
                                            <a href="mailto:info@validtheme.com">support@thesigmaskool.com</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Contact Information -->

    <!-- Start Map 
    ============================================= -->
    <!-- <div class="maps-area overflow-hidden default-padding-bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <div class="google-maps">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d48388.929990966964!2d-74.00332!3d40.711233!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew%20York%2C%20NY!5e0!3m2!1sen!2sus!4v1653598669477!5m2!1sen!2sus"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!-- End Map -->

     <!-- Start Footer 
    ============================================= -->
    <footer class="bg-dark footer-style-one text-light">
        <div class="footer-shape-style-one">
            <img src="assets/img/shape/2-light.png" alt="Image Not Found">
        </div>
        <div class="container">
            <div class="f-items default-padding">
                <div class="row">
                    <div class="col-lg-4 col-md-6 footer-item pr-30 pr-md-15 pr-xs-15">
                        <div class="f-item about">
                            <div class="footer-logo">
                                <img src="assets/img/logo-light.png" alt="Image Not Found">
                            </div>
                            <p>
                                Speak German. <br>Think German. <br>Succeed in Germany.
                            </p>
                            <ul class="footer-social">
                                <li>
                                    <a href="#">
                                        <i class="fab fa-facebook-f"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <img src="assets/img/icon/x.png" alt="Icon">
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fab fa-youtube"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fab fa-linkedin-in"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-6 footer-item">
                        <div class="f-item link">
                            <h4 class="widget-title">About</h4>
                            <ul>
                                <li>
                                    <a href="#aboutus">About Us</a>
                                </li>
                                <li>
                                    <a href="#courses">Courses</a>
                                </li>

                                <li>
                                    <a href="profile.html">Instructor profile</a>
                                </li>

                                <li>
                                    <a href="contact-us.html">Contact</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-6 footer-item">
                        <div class="f-item link">
                            <h4 class="widget-title">Quick Link</h4>
                            <ul>
                                <li>
                                    <a href="https://wa.me/919666892000">Request A Demo</a>
                                </li>
                                <li>
                                    <a href="notes.html">Get Hand written Notes</a>
                                </li>
                                <!-- <li>
                                    <a href="contact-us.html">Addmition</a>
                                </li> -->
                                <li>
                                    <a href="terms-and-conditions.html">Terms and Conditions</a>
                                </li>
                                <li>
                                    <a href="privacy-policy.html">privacy policy</a>
                                </li>
                                <!-- <li>
                                    <a href="about-us.html">Students</a>
                                </li> -->
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 footer-item">
                        <div class="f-item newsletter">
                            <h4 class="widget-title">Contact Info</h4>
                            <ul class="contact-list-two">
                                <li>
                                    <div class="icon">
                                        <i class="fas fa-phone-alt"></i>
                                    </div>
                                    <div class="info">
                                        <h5><a href="tel:+4733378901">+91 9666892000</a></h5>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="fas fa-envelope"></i>
                                    </div>
                                    <div class="info">
                                        <h5><a href="mailto:support@thesigmaskool.com">support@thesigmaskool.com</a>
                                        </h5>
                                    </div>
                                </li>
                            </ul>
                            <!-- <h4>Download sigma app</h4> -->
                            <!-- <ul class="app-store">
                                <li>
                                    <a href="#"><img src="assets/img/icon/4.png" alt="Image Not Found"></a>
                                </li>
                                <li>
                                    <a href="#"><img src="assets/img/icon/5.png" alt="Image Not Found"></a>
                                </li>
                                <li>
                                    <a href="#"><img src="assets/img/icon/6.png" alt="Image Not Found"></a>
                                </li>
                            </ul> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Start Footer Bottom -->
        <div class="footer-bottom style-one">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <p>&copy; Copyright 2025. All Rights Reserved by <a href="#">The SIGMA Skool</a></p>
                    </div>
                    <div class="col-lg-6 text-end">
                        <ul class="link-list">
                            <li>
                                <a href="terms-and-conditions.html">Terms</a>
                            </li>
                            <li>
                                <a href="privacy-policy.html">Privacy</a>
                            </li>
                            <li>
                                <a href="mailto:contact@example.com">Support</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Footer Bottom -->
    </footer>
    <!-- End Footer -->

    <!-- jQuery Frameworks
    ============================================= -->
    <script src="assets/js/jquery-3.7.1.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/jquery.appear.js"></script>
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/swiper-bundle.min.js"></script>
    <script src="assets/js/progress-bar.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/magnific-popup.min.js"></script>
    <script src="assets/js/count-to.js"></script>
    <script src="assets/js/jquery.nice-select.min.js"></script>
    <script src="assets/js/wow.min.js"></script>
    <script src="assets/js/YTPlayer.min.js"></script>
    <script src="assets/js/loopcounter.js"></script>
    <script src="assets/js/validnavs.js"></script>
    <script src="assets/js/gsap.js"></script>
    <script src="assets/js/ScrollTrigger.min.js"></script>
    <script src="assets/js/SplitText.min.js"></script>
    <script src="assets/js/main.js"></script>

</body>

</html>